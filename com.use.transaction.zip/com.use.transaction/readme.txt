TO achive transactional
*****************************************************************************
1 - we have to use @Trnasactional annotation on the method in which we are performing DB operation like save, update etc.
2 - Use @EnableTransactionManagement annotation on Main application class
*****************************************************************************
Along with @Trnasactional annotation we can add multiple properties like readOnly, Isolation , propagation, rollbackFor
Even though without adding these properties also we can play with @Transactional
*****************************************************************************

*****************
PROPOGATION LEVEL 
*****************
	REQUIRED - 	If we use propagation level as REQUIRED on multiple methods, then it 				maintained SAME TRANSACTION for all the method like Outer method then 				Inner method, and if any where exception occurs then it rollback 				previous operation, it basically work for RuntimeException by 				default, so if we want to use it for Checked Exception as well then 				we have to manage it by ourself
	
	REQUIRES_NEW - 	It maintained New physical transaction, that means a new physical 					transaction will always be created by the container. In other 					words the inner transaction may commit or rollback independently 					of the outer transaction i.e outer transaction will not be 					affected by the inner transaction result, they will run in 					distinct physical transaction.
	
	NESTED - It is also create new physical transaction that means inner transaction 			may not affect on outer with along with this we can set SAVEPOINT as well 			with NESTED propagation.
	
	MANDATORY - It state that existing opened transaction must already exist in 				container otherwise exception will be thrown by container
	
	NEVER - It is opposite of MANDATORY, that means never exist open transaction 			otherwise container will throw an exception
	
	NOT_SUPPORTED - This behavior will execute outside of the scope of any 			transaction. If any opened transaction already exist it will be paused.
	
	SUPPORTS - It will execute in the scope of a transaction if an opened transaction 			already exists. If there is not an already opened transaction the mothod 			will execute anyway but in a non-transactional way.
	
	
*****************
ISOLATION LEVEL 
*****************
	Isolation we used to avoid Dirty read, Non repeatable read and phantom reads situations.
	
	READ UNCOMMITED - Its not a best option, Read uncommitted means there may be a change to get uncommitted data. Its does not slove any problem (Dirty read, Non repeatable read and phantom read)
	
	READ COMMITED - Only committed data will get or allow to read. Its does not slove two problem (Non repeatable read and phantom read)
	
	REPEATABLE READs - Its does not slove one problem (phantom read), it keep lock on selected record, so others cant make any changes.
	
	SERIALIZABLE - It solved all problems like Dirty read, Non repeatable and phantom reads, because it keeps lock on range which we are trying to fetch through query. 
	
	