DROP TABLE IF EXISTS Passanger_info;

CREATE TABLE Passanger_info (
   pId INT AUTO_INCREMENT  PRIMARY KEY,
	 name VARCHAR(250) NOT NULL,
	 email VARCHAR(250) NOT NULL, 
	 source VARCHAR(250) NOT NULL, 
	 destination VARCHAR(250) NOT NULL,
	travelDate VARCHAR(250) NOT NULL,
	 pickupTime VARCHAR(250) NOT NULL,
	 arrivalTime VARCHAR(250) NOT NULL,
	fare VARCHAR(250) NOT NULL
);
