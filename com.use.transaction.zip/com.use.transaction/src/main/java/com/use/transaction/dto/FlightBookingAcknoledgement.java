package com.use.transaction.dto;

import com.use.transaction.entity.PassangerInfo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FlightBookingAcknoledgement {
	private String status;
	private double totalFare;
	private String pnrNo;
	private PassangerInfo passangerInfo;
	
	FlightBookingAcknoledgement(){}
	
	public FlightBookingAcknoledgement(String status, double totalFare, String pnrNo, PassangerInfo passangerInfo) {
		super();
		this.status = status;
		this.totalFare = totalFare;
		this.pnrNo = pnrNo;
		this.passangerInfo = passangerInfo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}
	public String getPnrNo() {
		return pnrNo;
	}
	public void setPnrNo(String pnrNo) {
		this.pnrNo = pnrNo;
	}
	public PassangerInfo getPassangerInfo() {
		return passangerInfo;
	}
	public void setPassangerInfo(PassangerInfo passangerInfo) {
		this.passangerInfo = passangerInfo;
	}
	
	
}
