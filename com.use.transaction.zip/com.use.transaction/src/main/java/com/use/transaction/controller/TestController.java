package com.use.transaction.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.use.transaction.dto.FlightBookingAcknoledgement;
import com.use.transaction.dto.FlightBookingRequest;
import com.use.transaction.service.FlightBookingService;

@RestController
public class TestController {
	@Autowired
	private FlightBookingService service; 
	
	/*
	 * {
	"passangerInfo":{
		"name": "transaction",
		"email": "transaction@test.com",
		"source": "mumbai",
		"destination": "goa",
		"travelDate": "14-12-2021",
		"pickupTime": "4.00pm",
		"arrivalTime": "6.00pm",
		"fare": "20000d"
	},
	"paymentInfo":{
		"accountNu": "acct1",
		"cardType": "DEBIT"
	}
}
	 * */
	@PostMapping("/bookFlightTicket")
	public FlightBookingAcknoledgement bookFlightTicket(@RequestBody FlightBookingRequest request) {
		return service.bookFilightTicket(request);
	}
}
