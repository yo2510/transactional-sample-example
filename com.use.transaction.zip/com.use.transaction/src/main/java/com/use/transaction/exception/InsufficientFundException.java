package com.use.transaction.exception;

public class InsufficientFundException extends RuntimeException{
	public InsufficientFundException(String msg){
		super(msg);
	}
}
