package com.use.transaction.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Payment_info")
public class PaymentInfo {
	@Id
	private String paymentId;
	private String accountNu;
	private double amount;
	private String cardType;
	private Long passangerId;
	
	PaymentInfo(){}

	public PaymentInfo(String paymentId, String accountNu, double amount, String cardType, Long passangerId) {
		super();
		this.paymentId = paymentId;
		this.accountNu = accountNu;
		this.amount = amount;
		this.cardType = cardType;
		this.passangerId = passangerId;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public String getAccountNu() {
		return accountNu;
	}

	public void setAccountNu(String accountNu) {
		this.accountNu = accountNu;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public Long getPassangerId() {
		return passangerId;
	}

	public void setPassangerId(Long passangerId) {
		this.passangerId = passangerId;
	}
	
	
}
