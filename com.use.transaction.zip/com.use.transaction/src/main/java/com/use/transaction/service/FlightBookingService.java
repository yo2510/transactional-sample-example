package com.use.transaction.service;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.use.transaction.dto.FlightBookingAcknoledgement;
import com.use.transaction.dto.FlightBookingRequest;
import com.use.transaction.entity.PassangerInfo;
import com.use.transaction.entity.PaymentInfo;
import com.use.transaction.repository.PassangerInfoRepository;
import com.use.transaction.repository.PaymentInfoRepository;
import com.use.transaction.utils.PaymentUtils;

@Service
public class FlightBookingService {
	@Autowired
	private PassangerInfoRepository passangerInfoRepository;
	@Autowired
	private PaymentInfoRepository paymentInfoRepository;
	
	@Transactional()
//	@Transactional(readOnly = false, isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRED)
	public FlightBookingAcknoledgement bookFilightTicket(FlightBookingRequest request) {
		PassangerInfo passangerInfo = request.getPassangerInfo();
		passangerInfo = passangerInfoRepository.save(passangerInfo);
		
		PaymentInfo paymentInfo = request.getPaymentInfo();
		PaymentUtils.validateCreditLimit(paymentInfo.getAccountNu(), passangerInfo.getFare());
		paymentInfo.setPassangerId(passangerInfo.getpId());
		paymentInfo.setAmount(passangerInfo.getFare());
		
		paymentInfoRepository.save(paymentInfo);
		return new FlightBookingAcknoledgement("Success", passangerInfo.getFare(), UUID.randomUUID().toString().split("-")[0], passangerInfo);
	}
}
