package com.use.transaction.utils;

import java.util.HashMap;
import java.util.Map;

import com.use.transaction.exception.InsufficientFundException;

public class PaymentUtils {
	private static Map<String, Double> paymentMap = new HashMap<String, Double>();
	
	static {
		paymentMap.put("acct1", 10000d);
		paymentMap.put("acct1", 12000d);
		paymentMap.put("acct1", 14000d);
		paymentMap.put("acct1", 16000d);
		paymentMap.put("acct1", 18000d);
	}
	
	public static boolean validateCreditLimit(String acct, Double paidAmt) {
		if(paidAmt > paymentMap.get(acct)) {
			throw new InsufficientFundException("Insifficient fund...!");
		} else {
			return true;
		}
	} 
}
