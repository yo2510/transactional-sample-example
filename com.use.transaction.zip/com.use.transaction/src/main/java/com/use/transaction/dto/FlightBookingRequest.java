package com.use.transaction.dto;


import com.use.transaction.entity.PassangerInfo;
import com.use.transaction.entity.PaymentInfo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FlightBookingRequest {
	private PassangerInfo passangerInfo;
	private PaymentInfo paymentInfo;
	
	FlightBookingRequest(){}

	public FlightBookingRequest(PassangerInfo passangerInfo, PaymentInfo paymentInfo) {
		super();
		this.passangerInfo = passangerInfo;
		this.paymentInfo = paymentInfo;
	}

	public PassangerInfo getPassangerInfo() {
		return passangerInfo;
	}

	public void setPassangerInfo(PassangerInfo passangerInfo) {
		this.passangerInfo = passangerInfo;
	}

	public PaymentInfo getPaymentInfo() {
		return paymentInfo;
	}

	public void setPaymentInfo(PaymentInfo paymentInfo) {
		this.paymentInfo = paymentInfo;
	}
	
	
}
